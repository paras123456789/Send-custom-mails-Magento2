<?php


namespace Mails\Sample1\Model\Mail;

class TransportBuilder extends \Magento\Framework\Mail\Template\TransportBuilder
{
    /**
     * @param Api\AttachmentInterface $attachment
     */
    public function addAttachmentPNG($pdfString)
    {
        $this->message->createAttachment(
            $pdfString,
            \Zend_Mime::TYPE_OCTETSTREAM,
            \Zend_Mime::DISPOSITION_ATTACHMENT,
            \Zend_Mime::ENCODING_BASE64,
             basename(rand().'.png')
        );
        return $this;
    }


    public function addAttachmentPDF($pdfString)
    {
        $this->message->createAttachment(
            $pdfString,
            \Zend_Mime::TYPE_OCTETSTREAM,
            \Zend_Mime::DISPOSITION_ATTACHMENT,
            \Zend_Mime::ENCODING_BASE64,
             basename(rand().'.pdf')
        );
        return $this;
    }

    public function addAttachmentDOC($pdfString)
    {
        $this->message->createAttachment(
            $pdfString,
            \Zend_Mime::TYPE_OCTETSTREAM,
            \Zend_Mime::DISPOSITION_ATTACHMENT,
            \Zend_Mime::ENCODING_BASE64,
             basename(rand().'.doc')
        );
        return $this;
    }


}
