<?php

namespace Mails\Sample1\Controller\Mail;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;

class Sendmail extends \Magento\Framework\App\Action\Action
{
  protected $_mediaDirectory;

  protected $_fileUploaderFactory;

  protected $_filesystem;
  /**
   * @var \Magento\Framework\App\Request\Http
   */
  protected $_request;
  /**
   * @var \Magento\Framework\Mail\Template\TransportBuilder
   */
  protected $_transportBuilder;
  /**
   * @var \Magento\Store\Model\StoreManagerInterface
   */
  protected $_storeManager;

  /**
  * @var \Magento\Framework\Message\ManagerInterface
  */
  protected $_messageManager;

  public function __construct(
      \Magento\Framework\App\Action\Context $context,
      \Magento\Framework\App\Request\Http $request,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Mails\Sample1\Model\Mail\TransportBuilder $transportBuilder,
      \Magento\Framework\Message\ManagerInterface $messageManager,
      \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
      \Magento\Framework\Filesystem $filesystem
  )
  {
      $this->_request = $request;
      $this->_transportBuilder = $transportBuilder;
      $this->_storeManager = $storeManager;
      $this->_messageManager = $messageManager;
      $this->_fileUploaderFactory = $fileUploaderFactory;
      $this->_filesystem = $filesystem;
      parent::__construct($context);
  }


  public function execute()
  {
      $count = count($_FILES['files']['name']);

      $filenames = array();

        for ($i=0; $i <$count ; $i++) {

          try {

            $pathurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'email_images/';
            $mediaDir = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
            $mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
            $uploader = $this->_fileUploaderFactory->create(['fileId' => 'files['.$i.']']);
            $uploader->setAllowedExtensions(['png','doc','pdf']);
            $uploader->setAllowRenameFiles(true);
            $path = $mediapath . '/email_images/';
            $result = $uploader->save($path);
            $filenames[] = $result['file'];

          } catch (\Exception $e) {
            $this->_messageManager->addError(__('file format not allowed ! use only png , pdf , doc'));
            return $this->_redirect('sample1/mail/');
          }


        }


      $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
      $filePath = $mediaUrl.'email_images/';

      $store = $this->_storeManager->getStore()->getId();
      $transport = $this->_transportBuilder->setTemplateIdentifier('mymodule_email_template')
          ->setTemplateOptions(['area' => 'frontend', 'store' => $store])
          ->setTemplateVars(
              [
                  'store' => $this->_storeManager->getStore(),
                  'massege'=>'Hello Magento 2'
              ]
          )
              ->setFrom([
                  'name' => 'Paras',
                  'email' => 'paras@gmail.com',
              ])
              ->addTo('paras@panaceatek.com', 'Customer');

              foreach ($filenames as $value) {

                if (pathinfo($value, PATHINFO_EXTENSION) == "png") {
                  $transport->addAttachmentPNG(file_get_contents($filePath.$value));
                }
                else if(pathinfo($value, PATHINFO_EXTENSION) == "pdf"){
                  $transport->addAttachmentPDF(file_get_contents($filePath.$value));
                }
                else if(pathinfo($value, PATHINFO_EXTENSION) == "doc"){
                  $transport->addAttachmentDOC(file_get_contents($filePath.$value));
                }
                else{
                  $this->_messageManager->addError(__('file format not allowed !'));
                  return $this->_redirect('sample1/mail/');
                }

              }


      try {
          $transport = $this->_transportBuilder->getTransport();
          $transport->sendMessage();

          $this->_messageManager->addSuccess(__('Mail has been sent !'));
          return $this->_redirect('sample1/mail/');

      } catch (\Exception $e) {
        $this->_messageManager->addError(__($e));
        return $this->_redirect('sample1/mail/');
      }

  }


}
