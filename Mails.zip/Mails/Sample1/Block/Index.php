<?php
namespace Mails\Sample1\Block;

class Index extends \Magento\Framework\View\Element\Template
{

}
