var config = {
    map: {
        '*': {
            jquery_min: 'Mails_Sample1/js/library/jquery-1.10.2.min',
            jquery_ui: 'Mails_Sample1/js/library/jquery-ui',
            bootstrap_min: 'Mails_Sample1/js/library/bootstrap.min',
            owl_carousel_min: 'Mails_Sample1/js/library/owl.carousel.min',
            scroll_it: 'Mails_Sample1/js/library/scrollIt.min',
            skroll_r: 'Mails_Sample1/js/library/skrollr.min',
            jquery_mcustom_scrollbar: 'Mails_Sample1/js/library/jquery.mCustomScrollbar',
            jquery_elevatezoom: 'Mails_Sample1/js/library/jquery.elevatezoom',

            angular: 'Mails_Sample1/js/library/angular',
            angular_route: 'Mails_Sample1/js/library/angular-route',
            angular_animate: 'Mails_Sample1/js/library/angular-animate',
            html2canvas: 'Mails_Sample1/js/library/html2canvas',

            app: 'Mails_Sample1/js/pipl-shirt/app',
            factory: 'Mails_Sample1/js/pipl-shirt/factory',
            shirt_controller: 'Mails_Sample1/js/pipl-shirt/shirt-controller',
            sample1_custom: 'Mails_Sample1/js/pipl-shirt/sample1_custom',
            custom_dir: 'Mails_Sample1/js/pipl-shirt/custom-directive',
            custom: 'Mails_Sample1/js/library/custom'
        }
    }
};
